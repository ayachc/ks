from datasets import load_dataset, Dataset, DatasetDict, concatenate_datasets
import os
import glob
import time
from pathlib import Path
from typing import Optional, Union
from datetime import datetime
import json

# 支持input正则匹配多个文件，但是不支持用正则的方式改名字
# 多对一合并请确保数据格式一致性，否则合并会失败
INPUT_DIR = '*.json'
OUTPUT_FILE = '*.jsonl'

class   NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        
        # Handle pandas Timestamp
        if isinstance(obj, datetime):
            return obj.isoformat()
        
        # Fallback to default handler
        return super().default(obj)

class DatasetConverter:
    """通用数据集格式转换器"""
    
    SUPPORTED_INPUT_FORMATS = {'csv', 'json', 'jsonl', 'parquet'}
    SUPPORTED_OUTPUT_FORMATS = {'csv', 'json', 'jsonl', 'parquet'}
    
    def __init__(self, 
                 input_path: str,
                 output_path: str):
        self.input_path = input_path
        self.output_path = output_path
        # print(f"输入路径: {self.input_path}")
        self.input_format = self._detect_input_format()
        print(f"输入文件格式: {self.input_format}")
        # print(f"输出路径: {self.output_path}")
        self.output_format = self._detect_output_format()
        print(f"输出文件格式: {self.output_format}")
        print("")
        time.sleep(0.2)
        
    def _detect_input_format(self) -> str:
        """改进的格式检测逻辑（目录自动追加通配符）"""
        if os.path.isdir(self.input_path):
            print("输入路径是文件夹，开始自动检测可转换文件格式")
            # 遍历一级目录寻找支持的文件格式
            for entry in os.listdir(self.input_path):
                entry_path = os.path.join(self.input_path, entry)
                if os.path.isfile(entry_path):
                    ext = Path(entry).suffix.lower().lstrip('.')
                    if ext in self.SUPPORTED_INPUT_FORMATS:
                        # 自动追加通配符模式
                        self.input_path = os.path.join(self.input_path, f"*.{ext}")
                        return ext
            raise ValueError(f"目录中未找到支持的文件格式: {self.input_path}")
        
        ext = Path(self.input_path).suffix.lower().lstrip('.')
        if ext in self.SUPPORTED_INPUT_FORMATS:
            return ext
        raise ValueError(f"不支持的输入格式: {ext} (检测路径: {self.input_path})")

    def _detect_output_format(self) -> str:
        if os.path.isdir(self.output_path):
            print("warning: 未指定输出文件格式")
            print("认为输入文件格式即为输出文件格式")
            ext = self.input_format
        ext = Path(self.output_path).suffix.lower().lstrip('.')

        if '*' in os.path.basename(self.output_path):
            temp_path = os.path.dirname(self.output_path)
            if not os.path.exists(temp_path):
                raise ValueError(f"目录路径不存在: {self.output_path}")
            self.output_path = temp_path
        
        if ext in self.SUPPORTED_OUTPUT_FORMATS:
            return ext
        raise ValueError(f"未找到支持的输出格式: {ext} (检测路径: {self.output_path})")

    def find_input_files(self) -> list[str]:
        """
        使用glob模式匹配获取所有输入文件路径形成列表排序后返回
        """
        # print("开始匹配输入文件")
        matched_files = glob.glob(self.input_path, recursive=True)
        
        if not matched_files:
            raise FileNotFoundError(f"未找到匹配文件: {self.input_path}")
        
        # 转换为绝对路径并排序
        abs_files = [os.path.abspath(f) for f in matched_files]
        abs_files = sorted(abs_files)

        print(f"找到 {len(abs_files)} 个文件: ")
        for f in abs_files:
            print(f)
        
        # 提取文件名并检查重名
        filenames = [os.path.basename(f) for f in abs_files]
        filenames = sorted(filenames)
        unique_filenames = list(dict.fromkeys(filenames))
        if len(unique_filenames) != len(filenames) and "*" in self.output_path:
            raise ValueError(f"文件名重名： {filenames}")
        print()
        time.sleep(0.2)
        return abs_files
    
    def load_dataset(self, streaming: bool = False) -> Union[Dataset, DatasetDict]:
        return load_dataset(
            "json" if self.input_format == "jsonl" else self.input_format,
            data_files=self.input_path,
            streaming=streaming
        )
    
    def write_dataset(self, dataset: Union[Dataset, DatasetDict], output_path: str):
        # 根据输出格式保存
        if self.output_format == 'parquet':
            dataset.to_parquet(output_path)
        elif self.output_format == 'jsonl':
            dataset.to_json(output_path, lines=True)
        elif self.output_format == 'csv':
            # 转换为pandas DataFrame并保存CSV
            df = dataset.to_pandas()
            df.to_csv(output_path, index=False, encoding='utf-8')
        elif self.output_format == 'json':
            dataset.to_json(output_path, orient='records', indent=4, lines=False)
        else:
            raise ValueError(f"不支持的输出格式: {self.output_format}")
    
    def merge_and_convert_files(self, files: list[str], output_path: str):
        """
        多文件合并转换
        """
        # 方案1：直接合并（适合小文件）
        if len(files) < 1000:  # 文件数量较少时
            try:
                dataset = concatenate_datasets([
                    load_dataset("json", data_files=f, split='train') 
                    for f in files
                ])
                dataset = dataset.filter(
                    lambda x: datetime(2024,8,1) <= x["contest_date"] < datetime(2025,2,1)
                )
                with open('2024_8.jsonl', 'w') as f:
                    for example in dataset:
                        json_str = json.dumps(example, cls=NumpyEncoder, ensure_ascii=False)
                        f.write(json_str + '\n')
                return
            except Exception as e:
                print(f"合并失败，错误信息： {str(e)}")

    def convert_file(self, input_path: str, output_path: str):
        """
        统一使用datasets库读取，根据输出格式选择写入方式
        """
        print(f"开始转换: {os.path.basename(input_path)} → {os.path.basename(output_path)}")
        # 读取数据集
        dataset = load_dataset(self.input_format, data_files=input_path, split='train')
        # 写入数据集
        self.write_dataset(dataset, output_path)
    
    def convert(self):
        # 开始获取所有文件路径：
        files = self.find_input_files()
        
        print(f"定向到的输出目录： {self.output_path}")
        if os.path.isdir(self.output_path):
            print(f"转换逻辑：多对多，{self.input_format}到{self.output_format}，开始转换")
            for f in files:
                self.convert_file(f, os.path.join(self.output_path, os.path.basename(f).split('.')[0] + f".{self.output_format}"))
        else:
            if(len(files) > 1):
                print(f"转换逻辑：多对一，{self.input_format}到{self.output_format}，开始合并转换")
                self.merge_and_convert_files(files, self.output_path)
            else:
                print(f"转换逻辑：单对单，{self.input_format}到{self.output_format}，开始转换")
                self.convert_file(files[0], self.output_path)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Dataset format converter')
    parser.add_argument('input', nargs='?', default=INPUT_DIR, help='Input directory/file pattern')
    parser.add_argument('output', nargs='?', default=OUTPUT_FILE, help='Output file path')
    args, unknown = parser.parse_known_args()
    
    # 参数数量验证
    if unknown:
        parser.error(f"检测到额外参数 {unknown}\n可能原因：路径包含通配符但未加引号\n正确用法：python file_x2x.py \"*.json\" \"merge.jsonl\"")

    # 更新全局路径变量
    INPUT_DIR = args.input
    OUTPUT_FILE = args.output

    converter = DatasetConverter(
        input_path=INPUT_DIR,
        output_path=OUTPUT_FILE,
    )
    converter.convert()
